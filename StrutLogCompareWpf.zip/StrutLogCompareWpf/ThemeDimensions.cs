namespace StrutLogCompareWpf;

/// <summary>
/// 与参照工程 ShellApp / Plugin.Abstractions 对齐的尺寸与字号，供主题 XAML 中 x:Static 使用。
/// </summary>
public static class ThemeDimensions
{
    public const double TitleFontSize = 28;
    public const double TitleCompactFontSize = 26;
    public const double SubtitleFontSize = 20;
    public const double BodyFontSize = 16;
    public const double CaptionFontSize = 15;
    public const double SmallFontSize = 13;
    public const double MicroFontSize = 12;
    public const double ButtonFontSize = 16;
    public const double DataGridHeaderFontSize = 15;
    public const double NavIconGlyphFontSize = 24;
    public const double CardIconGlyphFontSize = 32;
    public const double LineHeightDefault = 20;
    public const double LineHeightRelaxed = 22;

    public const double MainWindowWidth = 1320;
    public const double MainWindowHeight = 920;
    public const double MainWindowMinWidth = 1000;
    public const double MainWindowMinHeight = 720;
    public const double CaptionBarHeight = 52;
    public const double StatusBarHeight = 48;
    public const double ProgressBarHeight = 4;
    public const double ProgressBarAreaWidth = 150;

    public const double AuthorWindowWidth = 520;
    public const double AuthorWindowHeight = 620;

    public const double NavExpandedWidth = 260;
    public const double NavCollapsedWidth = 84;
    public const double NavItemHeight = 40;
    public const double NavIconMarginLeft = 22;
    public const double NavTextMarginLeft = 70;
    public const double NavIndicatorHeight = 16;
    public const double NavIndicatorWidth = 3;

    public const double IconButtonSize = 40;
    public const double IconViewboxLarge = 28;
    public const double IconViewboxMedium = 26;
    public const double IconViewboxSmall = 22;
    public const double IconCanvasSize = 24;
    public const double HamburgerBarWidth = 16;
    public const double HamburgerBarHeight = 2;
    public const double HamburgerGridSize = 22;
    public const double HomeIconSize = 32;

    public const double ControlHeight = 36;
    public const double ControlHeightLarge = 40;
    public const double ControlHeightSmall = 30;
    public const double ComboBoxMinHeight = 34;
    public const double CheckBoxBulletSize = 18;
    public const double ComboBoxGlyphWidth = 9;
    public const double ComboBoxGlyphHeight = 5;

    public const double PluginCardWidth = 300;
    public const double PluginCardMinHeight = 168;
    public const double PluginCardIconSize = 100;
    public const double PluginCardDescMaxHeight = 80;
    public const double AuthorAvatarSize = 44;
    public const double AuthorCloseButtonWidth = 140;
    public const double PluginCountMaxWidth = 248;

    public const double SpaceXxs = 2;
    public const double SpaceXs = 4;
    public const double SpaceSm = 8;
    public const double SpaceMd = 12;
    public const double SpaceLg = 16;
    public const double SpaceXl = 20;
    public const double SpaceXxl = 24;
    public const double SpaceXxxl = 30;
    public const double SpaceSection = 32;

    public const double RadiusSmall = 4;
    public const double RadiusMedium = 8;
    public const double RadiusLarge = 10;

    public const double StrokeThin = 1.5;
    public const double StrokeMedium = 1.7;
    public const double StrokeThick = 2;

    public const double ShadowBlurLevel1 = 14;
    public const double ShadowDepthLevel1 = 2;
    public const double ShadowOpacityLevel1 = 0.14;
    public const double ShadowBlurLevel2 = 24;
    public const double ShadowDepthLevel2 = 4;
    public const double ShadowOpacityLevel2 = 0.22;

    public const double OpacitySubtle = 0.5;
    public const double OpacityHover = 0.85;
    public const double OpacityPressed = 0.88;
    public const double OpacityDisabled = 0.4;
    public const double OpacityDisabledStrong = 0.3;
    public const double OpacityDisabledCheckBox = 0.45;

    public const double AnimMenuExpandMs = 250;
    public const double AnimFadeQuickMs = 100;
    public const double AnimFadeNormalMs = 180;
    public const double AnimFadeSlowMs = 250;
    public const double AnimEntranceFadeMs = 500;
    public const double AnimEntranceSlideMs = 350;
    public const double AnimEntranceSlideOffset = 40;
    public const double AnimPressMs = 60;

    public const double ShutdownWireDashLength = 96;
    public const double IconHoverScale = 1.08;
}
