namespace StrutLogCompareWpf.Models;

public sealed class CompareResultItem
{
    public int Sequence { get; init; }
    public string DisplayAction { get; init; } = string.Empty;
    public CompareStatus Status { get; init; }
    public string Summary { get; init; } = string.Empty;
    /// <summary>完整字段差异列表（每行一条），用于列表展开区与报告。</summary>
    public string? DiffDetail { get; init; }
    public bool HasDiffDetail => !string.IsNullOrWhiteSpace(DiffDetail);
    public string? OldJson { get; init; }
    public string? NewJson { get; init; }
    public bool OldIsJsonError { get; init; }
    public bool NewIsJsonError { get; init; }
    public string OldRawBlock { get; init; } = string.Empty;
    public string NewRawBlock { get; init; } = string.Empty;
    public string StatusText => Status switch
    {
        CompareStatus.Same => "一致",
        CompareStatus.Changed => "变更",
        CompareStatus.OnlyOld => "仅现日志",
        CompareStatus.OnlyNew => "仅新日志",
        CompareStatus.JsonError => "JSON失败",
        _ => Status.ToString()
    };
}
