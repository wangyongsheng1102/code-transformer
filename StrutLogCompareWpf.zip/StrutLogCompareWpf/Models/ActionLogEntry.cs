namespace StrutLogCompareWpf.Models;

public sealed class ActionLogEntry
{
    public int Sequence { get; init; }
    public string ActionName { get; init; } = string.Empty;
    public string MethodName { get; init; } = string.Empty;
    public string ActionMethod => string.IsNullOrWhiteSpace(MethodName) ? ActionName : $"{ActionName}#{MethodName}";
    public bool IsJsonError { get; set; }
    public string? JsonRaw { get; set; }
    public string? JsonNormalized { get; set; }
    public string RawBlock { get; set; } = string.Empty;
}
