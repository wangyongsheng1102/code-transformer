namespace StrutLogCompareWpf.Models;

public enum CompareStatus
{
    Same,
    Changed,
    OnlyOld,
    OnlyNew,
    JsonError
}
