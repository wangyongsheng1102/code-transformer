using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using StrutLogCompareWpf.Models;

namespace StrutLogCompareWpf.Services;

public sealed class LogParser
{
    private static readonly Regex StartRegex = new(@"LogBeanInterceptor start Action:\s*([A-Za-z0-9_]+)#([A-Za-z0-9_]+)", RegexOptions.Compiled);
    private static readonly Regex EndRegex = new(@"LogBeanInterceptor end Action:\s*([A-Za-z0-9_]+)", RegexOptions.Compiled);
    private const string JsonErrorPrefix = "LogBeanInterceptor err Action JSON - ";

    static LogParser()
    {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
    }

    public IReadOnlyList<ActionLogEntry> Parse(string filePath)
    {
        var lines = ReadLinesAutoEncoding(filePath);
        var result = new List<ActionLogEntry>();
        ActionLogEntry? current = null;
        var blockBuilder = new StringBuilder();
        var jsonBuilder = new StringBuilder();
        var collectingJson = false;
        var jsonStarted = false;
        var braceDepth = 0;

        foreach (var line in lines)
        {
            var startMatch = StartRegex.Match(line);
            if (startMatch.Success)
            {
                if (current is not null)
                {
                    current.RawBlock = blockBuilder.ToString();
                    result.Add(current);
                }

                current = new ActionLogEntry
                {
                    Sequence = result.Count + 1,
                    ActionName = startMatch.Groups[1].Value,
                    MethodName = startMatch.Groups[2].Value
                };
                blockBuilder.Clear();
                jsonBuilder.Clear();
                collectingJson = false;
                jsonStarted = false;
                braceDepth = 0;
                blockBuilder.AppendLine(line);
                continue;
            }

            if (current is null)
            {
                continue;
            }

            blockBuilder.AppendLine(line);

            if (line.Contains(JsonErrorPrefix, StringComparison.Ordinal))
            {
                current.IsJsonError = true;
            }

            if (line.Contains(">>> Request Parameters:", StringComparison.Ordinal))
            {
                collectingJson = true;
                jsonStarted = false;
                braceDepth = 0;
                jsonBuilder.Clear();
                continue;
            }

            if (EndRegex.IsMatch(line))
            {
                if (jsonBuilder.Length > 0)
                {
                    current.JsonRaw = jsonBuilder.ToString().Trim();
                    current.JsonNormalized = current.JsonRaw;
                }

                current.RawBlock = blockBuilder.ToString();
                result.Add(current);
                current = null;
                blockBuilder.Clear();
                jsonBuilder.Clear();
                collectingJson = false;
                jsonStarted = false;
                braceDepth = 0;
                continue;
            }

            if (collectingJson)
            {
                var normalizedLine = RemoveTailContext(line);
                if (!jsonStarted)
                {
                    var trimStart = normalizedLine.TrimStart();
                    if (trimStart.StartsWith("{", StringComparison.Ordinal) || trimStart.StartsWith("[", StringComparison.Ordinal))
                    {
                        jsonStarted = true;
                    }
                }

                if (jsonStarted)
                {
                    jsonBuilder.AppendLine(normalizedLine);
                    braceDepth += CountChar(normalizedLine, '{');
                    braceDepth -= CountChar(normalizedLine, '}');
                    if (braceDepth <= 0)
                    {
                        collectingJson = false;
                    }
                }
            }
        }

        if (current is not null)
        {
            if (jsonBuilder.Length > 0)
            {
                current.JsonRaw = jsonBuilder.ToString().Trim();
                current.JsonNormalized = current.JsonRaw;
            }

            current.RawBlock = blockBuilder.ToString();
            result.Add(current);
        }

        return result;
    }

    private static string[] ReadLinesAutoEncoding(string filePath)
    {
        var bytes = File.ReadAllBytes(filePath);
        var text = TryDecodeUtf8(bytes)
            ?? DecodeWithCodePage(bytes, 932)
            ?? Encoding.UTF8.GetString(bytes);
        return text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
    }

    private static string? TryDecodeUtf8(byte[] bytes)
    {
        try
        {
            // throwOnInvalidBytes=true can detect mojibake-prone input early.
            return new UTF8Encoding(encoderShouldEmitUTF8Identifier: false, throwOnInvalidBytes: true).GetString(bytes);
        }
        catch (DecoderFallbackException)
        {
            return null;
        }
    }

    private static string? DecodeWithCodePage(byte[] bytes, int codePage)
    {
        try
        {
            return Encoding.GetEncoding(codePage, EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback).GetString(bytes);
        }
        catch (DecoderFallbackException)
        {
            return null;
        }
    }

    private static string RemoveTailContext(string line)
    {
        var marker = line.LastIndexOf(" - {", StringComparison.Ordinal);
        if (marker <= 0)
        {
            return line;
        }

        var suffix = line[marker..];
        return suffix.EndsWith('}') ? line[..marker] : line;
    }

    private static int CountChar(string line, char ch)
    {
        var count = 0;
        foreach (var c in line)
        {
            if (c == ch)
            {
                count++;
            }
        }

        return count;
    }
}
