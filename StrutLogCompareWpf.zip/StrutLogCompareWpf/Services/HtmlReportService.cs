using System.Net;
using System.Text;
using System.IO;
using StrutLogCompareWpf.Models;

namespace StrutLogCompareWpf.Services;

public sealed class HtmlReportService
{
    public void Export(
        string outputPath,
        string oldLogPath,
        string newLogPath,
        IEnumerable<CompareResultItem> items)
    {
        var itemList = items.ToList();
        var html = BuildHtml(oldLogPath, newLogPath, itemList);
        File.WriteAllText(outputPath, html, new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));
    }

    private static string BuildHtml(string oldLogPath, string newLogPath, IReadOnlyList<CompareResultItem> items)
    {
        var now = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        var sb = new StringBuilder();
        sb.AppendLine("<!doctype html>");
        sb.AppendLine("<html lang=\"zh-CN\">");
        sb.AppendLine("<head><meta charset=\"utf-8\" />");
        sb.AppendLine("<title>Strut Log Compare Report</title>");
        sb.AppendLine("<style>");
        sb.AppendLine("body{font-family:Segoe UI,Arial,sans-serif;margin:16px;color:#222;}");
        sb.AppendLine(".meta{padding:10px;background:#f6f8fa;border:1px solid #d0d7de;border-radius:6px;}");
        sb.AppendLine("table.compare{width:100%;border-collapse:collapse;margin-top:12px;table-layout:fixed;}");
        sb.AppendLine("table.compare th,table.compare td{border:1px solid #d0d7de;padding:8px;vertical-align:top;} th{background:#f3f4f6;}");
        sb.AppendLine("th.col-seq,td.col-seq{width:3.5%;text-align:center;}");
        sb.AppendLine("th.col-action,td.col-action{width:11%;word-break:break-word;font-size:12px;line-height:1.35;}");
        sb.AppendLine("th.col-status,td.col-status{width:6.5%;white-space:nowrap;font-size:12px;}");
        sb.AppendLine("th.col-summary,td.col-summary{width:15%;font-size:12px;line-height:1.4;word-break:break-word;}");
        sb.AppendLine("th.col-detail,td.col-detail{width:64%;min-width:280px;}");
        sb.AppendLine(".action-sep{display:block;color:#666;font-size:11px;line-height:1.2;margin:2px 0;text-align:center;}");
        sb.AppendLine(".status-Same{color:#1f7a3d;font-weight:600;} .status-Changed{color:#005fb8;font-weight:600;} .status-OnlyOld{color:#8a5a00;font-weight:600;} .status-OnlyNew{color:#7f36d9;font-weight:600;} .status-JsonError{color:#b42318;font-weight:600;}");
        sb.AppendLine("td.col-detail pre{white-space:pre-wrap;word-break:break-word;background:#fafafa;border:1px solid #eee;padding:8px;border-radius:4px;max-height:560px;overflow:auto;font-size:12px;}");
        sb.AppendLine("details{margin:6px 0;} summary{cursor:pointer;font-weight:600;font-size:13px;}");
        sb.AppendLine("</style></head><body>");
        sb.AppendLine("<h2>Strut Log 比较报告</h2>");
        sb.AppendLine("<div class=\"meta\">");
        sb.AppendLine($"<div><b>生成时间:</b> {Encode(now)}</div>");
        sb.AppendLine($"<div><b>现日志:</b> {Encode(oldLogPath)}</div>");
        sb.AppendLine($"<div><b>新日志:</b> {Encode(newLogPath)}</div>");
        sb.AppendLine($"<div><b>总条目:</b> {items.Count}</div>");
        sb.AppendLine("</div>");
        sb.AppendLine("<table class=\"compare\">");
        sb.AppendLine("<thead><tr><th class=\"col-seq\">序号</th><th class=\"col-action\">Action</th><th class=\"col-status\">状态</th><th class=\"col-summary\">差异摘要</th><th class=\"col-detail\">详情</th></tr></thead><tbody>");

        foreach (var item in items)
        {
            var statusClass = $"status-{item.Status}";
            sb.AppendLine("<tr>");
            sb.AppendLine($"<td class=\"col-seq\">{item.Sequence}</td>");
            sb.AppendLine($"<td class=\"col-action\">{FormatActionCell(item.DisplayAction)}</td>");
            sb.AppendLine($"<td class=\"col-status {statusClass}\">{Encode(item.StatusText)}</td>");
            sb.AppendLine($"<td class=\"col-summary\">{FormatSummaryCell(item.Summary)}</td>");
            sb.AppendLine("<td class=\"col-detail\">");
            if (!string.IsNullOrWhiteSpace(item.DiffDetail))
            {
                sb.AppendLine("<details><summary>字段差异（完整）</summary><pre>" + Encode(item.DiffDetail) + "</pre></details>");
            }

            sb.AppendLine("<details><summary>现JSON</summary><pre>" + Encode(item.OldJson ?? "(无)") + "</pre></details>");
            sb.AppendLine("<details><summary>新JSON</summary><pre>" + Encode(item.NewJson ?? "(无)") + "</pre></details>");
            sb.AppendLine("<details><summary>现原始日志块</summary><pre>" + Encode(item.OldRawBlock) + "</pre></details>");
            sb.AppendLine("<details><summary>新原始日志块</summary><pre>" + Encode(item.NewRawBlock) + "</pre></details>");
            sb.AppendLine("</td>");
            sb.AppendLine("</tr>");
        }

        sb.AppendLine("</tbody></table></body></html>");
        return sb.ToString();
    }

    private static string Encode(string? value) => WebUtility.HtmlEncode(value ?? string.Empty);

    /// <summary>将「现Action -> 新Action」在箭头处换行，列更窄、易读。</summary>
    private static string FormatActionCell(string displayAction)
    {
        var s = displayAction ?? string.Empty;
        const string sep = " -> ";
        var idx = s.IndexOf(sep, StringComparison.Ordinal);
        if (idx < 0)
        {
            return Encode(s);
        }

        var left = s[..idx];
        var right = s[(idx + sep.Length)..];
        return $"{Encode(left)}<br/><span class=\"action-sep\">→</span><br/>{Encode(right)}";
    }

    /// <summary>摘要按「；」分行显示（与界面摘要分隔符一致）。</summary>
    private static string FormatSummaryCell(string summary)
    {
        if (string.IsNullOrWhiteSpace(summary))
        {
            return "";
        }

        var normalized = summary.Replace("\r\n", "\n").Replace('\r', '\n');
        if (normalized.Contains('；', StringComparison.Ordinal))
        {
            var parts = normalized.Split('；', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            return string.Join("<br/>", parts.Select(Encode));
        }

        return Encode(normalized).Replace("\n", "<br/>", StringComparison.Ordinal);
    }
}
