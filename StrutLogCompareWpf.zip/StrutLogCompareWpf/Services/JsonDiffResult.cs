namespace StrutLogCompareWpf.Services;

public sealed record JsonDiffResult(bool IsSame, string Summary, string? FullDetail);
