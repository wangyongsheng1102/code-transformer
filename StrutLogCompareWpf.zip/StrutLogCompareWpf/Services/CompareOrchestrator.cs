using StrutLogCompareWpf.Models;

namespace StrutLogCompareWpf.Services;

public sealed class CompareOrchestrator
{
    private readonly LogParser _parser = new();
    private readonly JsonDiffService _diffService = new();

    public IReadOnlyList<CompareResultItem> Compare(string oldLogPath, string newLogPath, Action<double>? progress = null)
    {
        progress?.Invoke(0.1);
        var oldEntries = _parser.Parse(oldLogPath);
        progress?.Invoke(0.4);
        var newEntries = _parser.Parse(newLogPath);
        progress?.Invoke(0.7);

        var result = new List<CompareResultItem>(Math.Max(oldEntries.Count, newEntries.Count));
        var oldIndex = 0;
        var newIndex = 0;
        var sequence = 1;
        while (oldIndex < oldEntries.Count || newIndex < newEntries.Count)
        {
            var oldEntry = oldIndex < oldEntries.Count ? oldEntries[oldIndex] : null;
            var newEntry = newIndex < newEntries.Count ? newEntries[newIndex] : null;

            if (oldEntry is not null && newEntry is not null && IsAligned(oldEntry, newEntry))
            {
                result.Add(BuildResult(sequence++, oldEntry, newEntry));
                oldIndex++;
                newIndex++;
                continue;
            }

            if (oldEntry is not null && newIndex + 1 < newEntries.Count && IsAligned(oldEntry, newEntries[newIndex + 1]))
            {
                result.Add(BuildResult(sequence++, null, newEntry));
                newIndex++;
                continue;
            }

            if (newEntry is not null && oldIndex + 1 < oldEntries.Count && IsAligned(oldEntries[oldIndex + 1], newEntry))
            {
                result.Add(BuildResult(sequence++, oldEntry, null));
                oldIndex++;
                continue;
            }

            result.Add(BuildResult(sequence++, oldEntry, newEntry));
            if (oldEntry is not null)
            {
                oldIndex++;
            }

            if (newEntry is not null)
            {
                newIndex++;
            }
        }

        progress?.Invoke(1.0);
        return result;
    }

    private CompareResultItem BuildResult(int sequence, ActionLogEntry? oldEntry, ActionLogEntry? newEntry)
    {
        if (oldEntry is null && newEntry is null)
        {
            throw new InvalidOperationException("Unexpected empty compare row.");
        }

        if (oldEntry is null && newEntry is not null)
        {
            return new CompareResultItem
            {
                Sequence = sequence,
                DisplayAction = newEntry.ActionMethod,
                Status = CompareStatus.OnlyNew,
                Summary = "新日志新增条目",
                NewJson = newEntry.JsonNormalized,
                NewIsJsonError = newEntry.IsJsonError,
                NewRawBlock = newEntry.RawBlock
            };
        }

        if (oldEntry is not null && newEntry is null)
        {
            return new CompareResultItem
            {
                Sequence = sequence,
                DisplayAction = oldEntry.ActionMethod,
                Status = CompareStatus.OnlyOld,
                Summary = "现日志独有条目（新日志缺失）",
                OldJson = oldEntry.JsonNormalized,
                OldIsJsonError = oldEntry.IsJsonError,
                OldRawBlock = oldEntry.RawBlock
            };
        }

        var displayAction = $"{oldEntry!.ActionMethod} -> {newEntry!.ActionMethod}";
        if (oldEntry.IsJsonError || newEntry.IsJsonError)
        {
            return new CompareResultItem
            {
                Sequence = sequence,
                DisplayAction = displayAction,
                Status = CompareStatus.JsonError,
                Summary = $"JSON生成失败: 现={oldEntry.IsJsonError}, 新={newEntry.IsJsonError}",
                OldJson = oldEntry.JsonNormalized,
                NewJson = newEntry.JsonNormalized,
                OldIsJsonError = oldEntry.IsJsonError,
                NewIsJsonError = newEntry.IsJsonError,
                OldRawBlock = oldEntry.RawBlock,
                NewRawBlock = newEntry.RawBlock
            };
        }

        var diff = _diffService.Diff(oldEntry.JsonNormalized, newEntry.JsonNormalized);
        return new CompareResultItem
        {
            Sequence = sequence,
            DisplayAction = displayAction,
            Status = diff.IsSame ? CompareStatus.Same : CompareStatus.Changed,
            Summary = diff.Summary,
            DiffDetail = diff.FullDetail,
            OldJson = oldEntry.JsonNormalized,
            NewJson = newEntry.JsonNormalized,
            OldRawBlock = oldEntry.RawBlock,
            NewRawBlock = newEntry.RawBlock
        };
    }

    private static bool IsAligned(ActionLogEntry oldEntry, ActionLogEntry newEntry)
    {
        return string.Equals(oldEntry.ActionMethod, newEntry.ActionMethod, StringComparison.Ordinal);
    }
}
