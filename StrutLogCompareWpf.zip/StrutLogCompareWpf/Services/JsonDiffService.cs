using System.Text.Json;
namespace StrutLogCompareWpf.Services;

public sealed class JsonDiffService
{
    public JsonDiffResult Diff(string? oldJson, string? newJson)
    {
        if (string.IsNullOrWhiteSpace(oldJson) && string.IsNullOrWhiteSpace(newJson))
        {
            return new JsonDiffResult(true, "两侧均无JSON", null);
        }

        if (string.IsNullOrWhiteSpace(oldJson) || string.IsNullOrWhiteSpace(newJson))
        {
            return new JsonDiffResult(false, "一侧无JSON", null);
        }

        try
        {
            using var oldDoc = JsonDocument.Parse(oldJson);
            using var newDoc = JsonDocument.Parse(newJson);
            var diffs = new List<string>();
            BuildDiff("$", true, oldDoc.RootElement, true, newDoc.RootElement, diffs);
            if (diffs.Count == 0)
            {
                return new JsonDiffResult(true, "字段一致", null);
            }

            var fullDetail = string.Join(Environment.NewLine, diffs);
            var summary = BuildSummaryPreview(diffs);
            return new JsonDiffResult(false, summary, fullDetail);
        }
        catch (JsonException)
        {
            return new JsonDiffResult(false, "JSON无法解析", null);
        }
    }

    private static string BuildSummaryPreview(IReadOnlyList<string> diffs)
    {
        const int maxInline = 8;
        if (diffs.Count <= maxInline)
        {
            return string.Join("；", diffs);
        }

        var head = string.Join("；", diffs.Take(5));
        return $"{head} … 共{diffs.Count}处差异（请展开下方「差异明细」查看全部）";
    }

    private static void BuildDiff(
        string path,
        bool oldExists,
        JsonElement oldElement,
        bool newExists,
        JsonElement newElement,
        IList<string> diffs)
    {
        if (!oldExists && !newExists)
        {
            return;
        }

        if (!oldExists)
        {
            diffs.Add($"{path}: 新增 {Format(newElement)}");
            return;
        }

        if (!newExists)
        {
            diffs.Add($"{path}: 删除 {Format(oldElement)}");
            return;
        }

        if (oldElement.ValueKind != newElement.ValueKind)
        {
            diffs.Add($"{path}: {Format(oldElement)} -> {Format(newElement)}");
            return;
        }

        if (oldElement.ValueKind == JsonValueKind.Object)
        {
            var oldMap = oldElement.EnumerateObject().ToDictionary(x => x.Name, x => x.Value);
            var newMap = newElement.EnumerateObject().ToDictionary(x => x.Name, x => x.Value);
            var keys = oldMap.Keys.Union(newMap.Keys).Distinct().OrderBy(x => x);
            foreach (var key in keys)
            {
                var hasOld = oldMap.TryGetValue(key, out var oldValue);
                var hasNew = newMap.TryGetValue(key, out var newValue);
                BuildDiff($"{path}.{key}", hasOld, oldValue, hasNew, newValue, diffs);
            }

            return;
        }

        if (oldElement.ValueKind == JsonValueKind.Array)
        {
            var oldItems = oldElement.EnumerateArray().ToArray();
            var newItems = newElement.EnumerateArray().ToArray();
            if (oldItems.Length != newItems.Length)
            {
                diffs.Add($"{path}.length: {oldItems.Length} -> {newItems.Length}");
            }

            var max = Math.Max(oldItems.Length, newItems.Length);
            for (var i = 0; i < max; i++)
            {
                var hasOld = i < oldItems.Length;
                var hasNew = i < newItems.Length;
                var oldValue = hasOld ? oldItems[i] : default;
                var newValue = hasNew ? newItems[i] : default;
                BuildDiff($"{path}[{i}]", hasOld, oldValue, hasNew, newValue, diffs);
            }

            return;
        }

        var oldText = Format(oldElement);
        var newText = Format(newElement);
        if (!string.Equals(oldText, newText, StringComparison.Ordinal))
        {
            diffs.Add($"{path}: {oldText} -> {newText}");
        }
    }

    private static string Format(JsonElement element)
    {
        return element.ValueKind switch
        {
            JsonValueKind.String => $"\"{element.GetString()}\"",
            JsonValueKind.Number => element.GetRawText(),
            JsonValueKind.True => "true",
            JsonValueKind.False => "false",
            JsonValueKind.Null => "null",
            JsonValueKind.Object => "{...}",
            JsonValueKind.Array => "[...]",
            _ => element.GetRawText()
        };
    }
}
