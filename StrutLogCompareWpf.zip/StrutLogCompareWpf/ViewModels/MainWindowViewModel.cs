using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using Microsoft.Win32;
using StrutLogCompareWpf.Models;
using StrutLogCompareWpf.Services;

namespace StrutLogCompareWpf.ViewModels;

public sealed class MainWindowViewModel : INotifyPropertyChanged
{
    private readonly CompareOrchestrator _orchestrator = new();
    private readonly HtmlReportService _reportService = new();
    private readonly RelayCommand _runCompareCommand;
    private readonly RelayCommand _exportReportCommand;
    private string _oldLogPath = string.Empty;
    private string _newLogPath = string.Empty;
    private CompareResultItem? _selectedItem;
    private bool _isBusy;
    private double _progressValue;

    public MainWindowViewModel()
    {
        BrowseOldLogCommand = new RelayCommand(_ => BrowseOldLog());
        BrowseNewLogCommand = new RelayCommand(_ => BrowseNewLog());
        _runCompareCommand = new RelayCommand(_ => RunCompare(), _ => CanRunCompare());
        _exportReportCommand = new RelayCommand(_ => ExportReport(), _ => CanExportReport());
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public ObservableCollection<CompareResultItem> Results { get; } = new();
    public ICommand BrowseOldLogCommand { get; }
    public ICommand BrowseNewLogCommand { get; }
    public ICommand RunCompareCommand => _runCompareCommand;
    public ICommand ExportReportCommand => _exportReportCommand;

    public string OldLogPath
    {
        get => _oldLogPath;
        set
        {
            if (SetField(ref _oldLogPath, value))
            {
                _runCompareCommand.RaiseCanExecuteChanged();
            }
        }
    }

    public string NewLogPath
    {
        get => _newLogPath;
        set
        {
            if (SetField(ref _newLogPath, value))
            {
                _runCompareCommand.RaiseCanExecuteChanged();
            }
        }
    }

    public CompareResultItem? SelectedItem
    {
        get => _selectedItem;
        set => SetField(ref _selectedItem, value);
    }

    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (SetField(ref _isBusy, value))
            {
                _runCompareCommand.RaiseCanExecuteChanged();
                _exportReportCommand.RaiseCanExecuteChanged();
            }
        }
    }

    public double ProgressValue
    {
        get => _progressValue;
        set => SetField(ref _progressValue, value);
    }

    private void BrowseOldLog()
    {
        var path = SelectLogFile();
        if (path is not null)
        {
            OldLogPath = path;
        }
    }

    private void BrowseNewLog()
    {
        var path = SelectLogFile();
        if (path is not null)
        {
            NewLogPath = path;
        }
    }

    private string? SelectLogFile()
    {
        var dialog = new OpenFileDialog
        {
            Filter = "Log files (*.log)|*.log|All files (*.*)|*.*",
            CheckFileExists = true
        };
        return dialog.ShowDialog() == true ? dialog.FileName : null;
    }

    private bool CanRunCompare() =>
        !IsBusy &&
        !string.IsNullOrWhiteSpace(OldLogPath) &&
        !string.IsNullOrWhiteSpace(NewLogPath) &&
        File.Exists(OldLogPath) &&
        File.Exists(NewLogPath);

    private void RunCompare()
    {
        IsBusy = true;
        ProgressValue = 0;
        Results.Clear();

        try
        {
            var compareResult = _orchestrator.Compare(OldLogPath, NewLogPath, p => ProgressValue = p * 100);
            foreach (var item in compareResult)
            {
                Results.Add(item);
            }

            SelectedItem = Results.FirstOrDefault();
            _exportReportCommand.RaiseCanExecuteChanged();
        }
        finally
        {
            IsBusy = false;
        }
    }

    private bool CanExportReport() => !IsBusy && Results.Count > 0;

    private void ExportReport()
    {
        var dialog = new SaveFileDialog
        {
            Filter = "HTML files (*.html)|*.html",
            FileName = $"strut-compare-report-{DateTime.Now:yyyyMMdd-HHmmss}.html",
            AddExtension = true,
            DefaultExt = ".html"
        };

        if (dialog.ShowDialog() != true)
        {
            return;
        }

        try
        {
            _reportService.Export(dialog.FileName, OldLogPath, NewLogPath, Results);
            MessageBox.Show($"报告已导出：\n{dialog.FileName}", "导出成功", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"导出失败：{ex.Message}", "导出失败", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private bool SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
        {
            return false;
        }

        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        return true;
    }
}
