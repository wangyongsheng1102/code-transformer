using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace StrutLogCompareWpf;

public partial class MainWindow : Window
{
    private ScrollViewer? _oldJsonScrollViewer;
    private ScrollViewer? _newJsonScrollViewer;
    private bool _isSyncingScroll;

    public MainWindow()
    {
        InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        _oldJsonScrollViewer ??= FindChild<ScrollViewer>(OldJsonTextBox);
        _newJsonScrollViewer ??= FindChild<ScrollViewer>(NewJsonTextBox);
        if (_oldJsonScrollViewer is null || _newJsonScrollViewer is null)
        {
            return;
        }

        _oldJsonScrollViewer.ScrollChanged -= OldJsonScrollViewer_ScrollChanged;
        _newJsonScrollViewer.ScrollChanged -= NewJsonScrollViewer_ScrollChanged;
        _oldJsonScrollViewer.ScrollChanged += OldJsonScrollViewer_ScrollChanged;
        _newJsonScrollViewer.ScrollChanged += NewJsonScrollViewer_ScrollChanged;
    }

    private void OldJsonScrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e)
    {
        SyncScroll(_oldJsonScrollViewer, _newJsonScrollViewer);
    }

    private void NewJsonScrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e)
    {
        SyncScroll(_newJsonScrollViewer, _oldJsonScrollViewer);
    }

    private void SyncScroll(ScrollViewer? source, ScrollViewer? target)
    {
        if (_isSyncingScroll || source is null || target is null)
        {
            return;
        }

        _isSyncingScroll = true;
        try
        {
            target.ScrollToVerticalOffset(source.VerticalOffset);
            target.ScrollToHorizontalOffset(source.HorizontalOffset);
        }
        finally
        {
            _isSyncingScroll = false;
        }
    }

    private static T? FindChild<T>(DependencyObject parent) where T : DependencyObject
    {
        var count = VisualTreeHelper.GetChildrenCount(parent);
        for (var i = 0; i < count; i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is T typedChild)
            {
                return typedChild;
            }

            var nested = FindChild<T>(child);
            if (nested is not null)
            {
                return nested;
            }
        }

        return null;
    }
}
