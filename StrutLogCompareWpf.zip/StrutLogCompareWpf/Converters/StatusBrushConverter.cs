using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using StrutLogCompareWpf.Models;

namespace StrutLogCompareWpf.Converters;

public sealed class StatusBrushConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is not CompareStatus status)
        {
            return Brushes.Gray;
        }

        return status switch
        {
            CompareStatus.Same => new SolidColorBrush(Color.FromRgb(46, 139, 87)),
            CompareStatus.Changed => new SolidColorBrush(Color.FromRgb(0, 95, 184)),
            CompareStatus.OnlyOld => new SolidColorBrush(Color.FromRgb(183, 121, 31)),
            CompareStatus.OnlyNew => new SolidColorBrush(Color.FromRgb(123, 66, 245)),
            CompareStatus.JsonError => new SolidColorBrush(Color.FromRgb(197, 48, 48)),
            _ => Brushes.Gray
        };
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
