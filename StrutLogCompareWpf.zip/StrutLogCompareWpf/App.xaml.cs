using System.Windows;

namespace StrutLogCompareWpf;

public partial class App : Application
{
}
